//const  request = require("http");

let data;
// accessData();

function accessData()
{
    console.log(document.querySelector("#dropDownMenu").value);
    if (document.querySelector("#dropDownMenu").value == "logError") {
    const request = new XMLHttpRequest();
    request.open("POST",`http://127.0.0.1:3000/log_error`, true);
    request.onload = function() {
        data = this.response;

        if (request.status == 200)
        {
            console.log(data);
            document.querySelector("#test").innerHTML= data;
        }
        else
        {
            console.log(`Error occurred: Status: ${request.status}`);
        }
    };
    request.send();
    }

    else if (document.querySelector("#dropDownMenu").value == "logWarning") {
        const request = new XMLHttpRequest();
        request.open("POST",`http://127.0.0.1:3000/log_warning`, true);
        request.onload = function() {
            data = this.response;
    
            if (request.status == 200)
            {
                console.log(data);
                document.querySelector("#test").innerHTML= data;
            }
            else
            {
                console.log(`Error occurred: Status: ${request.status}`);
            }
        };
        request.send();
        }

        else if (document.querySelector("#dropDownMenu").value == "readError") {
            const request = new XMLHttpRequest();
            request.open("GET",`http://127.0.0.1:3000/errors`, true);
            request.onload = function() {
                data = this.response;
        
                if (request.status == 200)
                {
                    // data.forEach(error => {
                    //     error.document.querySelector("#test");
                    // });
                    document.querySelector("#test").innerHTML= data;
                }
                else
                {
                    console.log(`Error occurred: Status: ${request.status}`);
                }
            };
            request.send();
            }

            else if (document.querySelector("#dropDownMenu").value == "readWarning") {
                const request = new XMLHttpRequest();
                request.open("GET",`http://127.0.0.1:3000/warnings`, true);
                request.onload = function() {
                    data = this.response;
            
                    if (request.status == 200)
                    {
                        document.querySelector("#test").innerHTML= data;
                    }
                    else
                    {
                        console.log(`Error occurred: Status: ${request.status}`);
                    }
                };
                request.send();
                }

                else if (document.querySelector("#dropDownMenu").value == "readAll") {
                    const request = new XMLHttpRequest();
                    request.open("GET",`http://127.0.0.1:3000/all`, true);
                    request.onload = function() {
                        data = this.response;
                
                        if (request.status == 200)
                        {
                            console.log(data);
                            document.querySelector("#test").innerHTML= data;
                        }
                        else
                        {
                            console.log(`Error occurred: Status: ${request.status}`);
                        }
                    };
                    request.send();
                    }
}
    function testError() {
    const request = new XMLHttpRequest();
    request.open("GET",`http://127.0.0.1:3000/`, true);
    request.onload = function() {
        data = this.response;
        if (request.status == 200) {
            //console.log("Response OK.");

            document.querySelector("#test").innerHTML = data;
            
        }
        else {
            //console.log(`Error ocurred: Status: ${request.status}`);

            document.querySelector("#test").innerHTML = data;
        }
  };
  request.send();
}

// function access()
// {
//     const request = new XMLHttpRequest();
//     request.open("GET",`http://127.0.0.1:3000/log_error`, true);

//     request.onload = function() {
//         data = this.response;

//         if (request.status == 200)
//         {
//             console.log(data);
//             document.querySelector("#test").innerHTML= data;
//         }
//         else
//         {
//             console.log(`Error occurred: Status: ${request.status}`);
//         }
//     };
//     request.send();
// }

// const hostname = '127.0.0.1';
// const port = 3000;

// const server = http.createServer( (req,res) => {

//     //const method = req.method;
//     //const url = req.url;
//     const {method, url} = req;

//     res.statusCode = 200;
//     res.setHeader('Content-type','text/plain');

//     res.setHeader('Access-Control-Allow-Origin', '*');

//     // res.write(`Welcome to our web server!\n`);
//     // res.write(`Method:${method}, URL:${url}`);

//     if (url === '/log_error') 
//     {
//         // res.write(`Here's a cat.`);
//         // res.end();
//         const fs = require('fs');

// fs.writeFile('october31.txt', 'Hello there - have a great day!', err => {
//     if(err) throw err;
//     console.log('File written.');
// });
//     }
// });