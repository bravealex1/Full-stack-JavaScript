const http = require('http');
const fs = require('fs');

const hostname = '127.0.0.1';
const port = 3000;

const server = http.createServer( (req,res) => {

    //const method = req.method;
    //const url = req.url;
    const {url} = req;

    res.statusCode = 200;
    res.setHeader('Content-type','text/plain');

    res.setHeader('Access-Control-Allow-Origin', '*');


    const date = new Date();

        if (url === '/log_error') 
    { 
        let fileExists = fs.existsSync('error.txt');
        if (fileExists == true)
        {
        fs.appendFile('error.txt', `Error occurred at: ${date}\n`, err => {
        if(err) throw err;
        res.end();
    });}
    if (fileExists == false) 
    {
        fs.writeFile('error.txt', `Error occurred at: ${date}\n`, err => {
            if(err) throw err;
            res.end();
    });}
    }
    
    else if (url === '/log_warning')
    {
        let fileExists = fs.existsSync('warning.txt');
        if (fileExists == true)
        {
        fs.appendFile('warning.txt', `Warning occurred at: ${date}\n`, err => {
        if(err) throw err;
        console.log(date);
        res.end();
    });}
    if (fileExists == false) 
    {
        fs.writeFile('warning.txt', `Warning occurred at: ${date}`, err => {
            if(err) throw err;
            res.end();
    });}
        
    }

    else if (url === '/errors')
    {
        const fs = require('fs');
        let fileExists = fs.existsSync('error.txt');
        console.log(fileExists);
        if (fileExists == true)
        {
        fs.readFile('error.txt', (err, data) =>{
            if (err) throw err;
            res.write(data + "\n");
            console.log(data);
            res.end();
        }); 
     }
     else {
        res.write("Nothing");
        res.end();
     }
}

    else if (url === '/warnings')
    {
        let fileExists = fs.existsSync('warning.txt');
        if (fileExists == true)
        {
        fs.readFile('warning.txt', (err, data) =>{
            if (err) throw err;
            res.write("\n" + data);
            res.end();
        });
    }
    else {
        res.write("Nothing");
        res.end();
    }
    }

    else if (url === '/all')
    {
        let fileExists = fs.existsSync('error.txt');
        if (fileExists == true)
        {
        fs.readFile('error.txt', (err, data) =>{
            if (err) throw err;
            res.write("\n" + data);
        });}
        let fileExists1 = fs.existsSync('warning.txt');
        if (fileExists1 == true)
        {
        fs.readFile('warning.txt', (err, data) =>{
            if (err) throw err;
            res.write("\n" + data);
            res.end();
        });}
    }
    else {
        res.statusCode = 404;
        res.write(`Resource not available. Status code: ${res.statusCode}\n`);
        res.end();
    }
});

server.listen(port, hostname, () => {
    console.log(`Server running at ${hostname}:${port}`);
});